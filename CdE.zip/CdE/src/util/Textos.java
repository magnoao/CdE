package util;

public class Textos {
	public static final String TITULO = "Empr�stimos";
	public static final String TEXTOMENUATUAL1 = "Pessoa";
	public static final String TEXTOMENUATUAL2 = "Item";
	public static final String TEXTOMENUATUAL3 = "Emprestimo";
	public static final String TEXTOMENUATUAL4 = "Tipo";
	public static final String TEXTOMENUATUAL5 = "Home";
	public static final String TEXTOSUBMENU01 = "listaPessoa";
	public static final String TEXTOSUBMENU02 = "listaItem";
	public static final String TEXTOSUBMENU03 = "listaEmprestimo";
	public static final String TEXTOSUBMENU04 = "listaPessoaBloqueada";
	public static final String TEXTOSUBMENU05 = "listaPessoaComItens";
	public static final String TEXTOSUBMENU06 = "listaItemIndisponivel";
	public static final String TEXTOSUBMENU07 = "formPessoa";
	public static final String TEXTOSUBMENU08 = "formItem";
	public static final String TEXTOSUBMENU09 = "formEmprestimo";
	public static final String TEXTOSUBMENU10 = "listaTipo";
	public static final String TEXTOSUBMENU11 = "formTipo";
	public static final String TEXTOSUBMENU12 = "listaItensDisponiveis";
	public static final String TEXTOSUBMENU13 = "listaItensBloqueados";

	public static final String[] menusTextos = {"Home",TEXTOMENUATUAL1,TEXTOMENUATUAL2, TEXTOMENUATUAL3};

}
