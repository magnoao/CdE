package control.logic;



public interface Logic {
	
	public String execute(Object objeto) throws Exception;

}
