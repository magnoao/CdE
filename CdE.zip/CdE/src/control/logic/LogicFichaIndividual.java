package control.logic;

public class LogicFichaIndividual implements Logic{

	public String execute(Object objeto) throws Exception {
		
		return null;
	}

}
