package control.logic;



public class LogicRAlunoPTurma implements Logic{
	
	
	public String execute(Object objeto)
			throws Exception {
		
	
	    return null;
	}
}

